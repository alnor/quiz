<?php

namespace core;

/**
 * class DB
 * 
 */
abstract class DB
{

  /** Aggregations: */

  /** Compositions: */

   /*** Attributes: ***/






} // end of DB
?>
