<?php

/**
 * Массив настроек для DSN
 */

$db = array(	'driver' => 'mysql',
				'persistent' => false,
				'host' => 'localhost',
				'login' => 'root',
				'password' => 'root12',
				'database' => 'quiz',
				'prefix' => '',
			);
?>
